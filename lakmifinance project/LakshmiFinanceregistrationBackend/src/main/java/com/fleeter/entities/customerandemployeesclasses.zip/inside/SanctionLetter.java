package com.fleeter.entities.inside;

import com.fleeter.entities.applicant.LoanApplicationForm;



public class SanctionLetter {
	
	private LoanApplicationForm loanApplicationForm;
	private Long approvedLoan;
	private String remark;
	private boolean isLoanDisbursed;

}
