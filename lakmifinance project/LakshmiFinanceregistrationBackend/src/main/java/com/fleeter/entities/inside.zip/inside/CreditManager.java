package com.fleeter.entities.inside;


import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import com.fleeter.entities.applicant.Person;
import com.fleeter.entities.applicant.User;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Entity
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class CreditManager extends User{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long cmid;

	@OneToOne(cascade = CascadeType.ALL)
	private Person person;
	
	@OneToOne
	private OperationExecutive oe;
	
	
//	@OneToMany
//	private Set<LoanApplicationForm> loanApplicationForms;
//	
//	@OneToMany
//	private Set<LoanApplicationForm> fileOKLoanApplicationForms;
//	
//	@OneToMany
//	private Set<LoanApplicationForm> fileNotOkloanApplicationForms;
	
}
